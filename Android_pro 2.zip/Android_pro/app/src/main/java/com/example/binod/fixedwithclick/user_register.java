package com.example.binod.fixedwithclick;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextClock;
import android.widget.TextView;
import android.widget.Toast;

import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

public class user_register extends AppCompatActivity {
    private  static final Pattern NAME_PATTERN = Pattern.compile("^[a-zA-Z]+$");

    DatabaseHelper db;
        Button backtologin;
        EditText emailid,name;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_user_register);

    }


    public void onRegisterClick(View v) {
        if (v.getId() == R.id.r_button) {

            db = new DatabaseHelper(this);

             name = (EditText) findViewById(R.id.name);
             EditText username = (EditText) findViewById(R.id.l_username);
            emailid = (EditText) findViewById(R.id.email);
             EditText password = (EditText) findViewById(R.id.password);
             EditText cpassword = (EditText) findViewById(R.id.cpassword);
            backtologin = (Button) findViewById(R.id.backtologin);
            Button r_button = (Button) findViewById(R.id.r_button);


                    String sname = name.getText().toString();
                    String susername = username.getText().toString();
                    String semailid = emailid.getText().toString();
                    String spassword = password.getText().toString();
                    String scpassword = cpassword.getText().toString();



            if (sname.equals("")) {
                    Toast.makeText(getApplicationContext(), "please enter your name", Toast.LENGTH_SHORT).show();
                }

                if (susername.equals("")) {
                    Toast.makeText(getApplicationContext(), "please enter your Username", Toast.LENGTH_LONG).show();
                }

                if (spassword.equals("")) {
                    Toast.makeText(getApplicationContext(), "please enter password", Toast.LENGTH_LONG).show();
                } else {
                    if (!spassword.equals(scpassword)) {
                        Toast.makeText(getApplicationContext(), "password doesnot match", Toast.LENGTH_LONG).show();
                    }
                   else if(cpassword.length() < 6)
                    {
                        Toast.makeText(getApplicationContext(), "password must be more then 6 character ", Toast.LENGTH_LONG).show();
                        password.setError("enter minimum 6 characters");
                    }
                   else if(validateEmail() == false )
                    {
                        Toast.makeText(getApplicationContext(), "NOT a valid email id ", Toast.LENGTH_SHORT).show();
                        emailid.setError("enter valid email id");
                    }
                  else  if(validatename() == false)
                    {

                        Toast.makeText(getApplicationContext(), "please enter a valid name", Toast.LENGTH_SHORT).show();
                        name.setError("no special character in name");
                    }

                            else
                    {
                        boolean checkmail = db.checkmail(semailid);
                        boolean checkusername = db.checkusername(susername);
                        if (checkmail == true && checkusername == true) {
                            boolean insert = db.insertreg(sname, susername, semailid, spassword);
                            if (insert == true) {
                                Toast.makeText(getApplicationContext(), "successfull Register please Log in", Toast.LENGTH_LONG).show();
                                Intent e = new Intent(user_register.this, User_Login.class);
                                e.putExtra("username", susername);
                                startActivity(e);

                            }
                        } else {
                            Toast.makeText(getApplicationContext(), "email id or username already exit", Toast.LENGTH_LONG).show();
                        }
                        }
                    }
                }
            }
           // });

    public  void gotologinfromreg(View v){
        switch(v.getId()){
            case R.id.backtologin:
                startActivity(new Intent(user_register.this,User_Login.class));

        }

    }

 public boolean validateEmail() {
     String emailid1 = emailid.getText().toString();
    if(emailid1.isEmpty())
    {
         Toast.makeText( user_register.this, "pleae enter email id", Toast.LENGTH_SHORT );
         return  false;
    }
    else if (!Patterns.EMAIL_ADDRESS.matcher(emailid1).matches()) {
       //  Toast.makeText(user_register.this, "ininivalid email id ", Toast.LENGTH_SHORT);
         return false;
     }
                 else{
                     return true;

     }
 }

 public  boolean validatename() {
     String name11 = name.getText().toString();
     if(!NAME_PATTERN.matcher(name11).matches())
     {
         return false;
     }
     else
     {
         return true;
     }
 }
}

