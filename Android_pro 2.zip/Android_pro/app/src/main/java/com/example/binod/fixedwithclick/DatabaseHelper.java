package com.example.binod.fixedwithclick;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.strictmode.SqliteObjectLeakedViolation;

public class DatabaseHelper extends SQLiteOpenHelper {

    public DatabaseHelper(Context context) {

        super(context, "click", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
       db.execSQL("Create table userregister(ID integer primary key Autoincrement,name text,username text,email text, password text)");
        db.execSQL("Create table finaldetail(ID integer primary key Autoincrement,username text, department text, complain text, others text, location text, image blob ,imagename text, datetime text, detaildescrip text,status text)");
        db.execSQL("Create table admin(ID integer primary key Autoincrement, username text, password text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists userregister");
        db.execSQL("drop table if exists finaldetail");
        db.execSQL("drop table if exists admin");
    }

    public boolean insertreg(String name, String username, String email, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contextValues = new ContentValues();
        contextValues.put("name", name);
        contextValues.put("username", username);
        contextValues.put("email", email);
        contextValues.put("password", password);
        long result = db.insert("userregister", null, contextValues);
        if (result == -1) return false;
        else return true;
    }

    public boolean checkmail(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("Select * from userregister where email=?", new String[]{email});
        if (cursor.getCount() > 0) return false;
        else return true;

    }

    public boolean checkusername(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("Select * from userregister where username=?", new String[]{username});
        if (cursor.getCount() > 0) return false;
        else return true;
    }


    /* checking email id and password*/

    boolean checklogin(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("Select * from userregister where username=? and password=?", new String[]{username, password});
        if(cursor.getCount()>0)
        return true;
        else
            return false;

    }

    // to insert the final detail
    public boolean finalinsert(String username, String department, String complain, String others, String location, byte[] image,String imagename,String datetime, String detaildescrip, String status){

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("username",username);
        cv.put("department",department);
        cv.put("complain",complain);
        cv.put("others",others);
        cv.put("location",location);
        cv.put("image",image);
        cv.put("imagename",imagename);
        cv.put("datetime", datetime);
        cv.put("detaildescrip", detaildescrip);
        cv.put("status",status);
        long result = db.insert("finaldetail", null, cv);
        if(result == -1)
            return false;
        return true;
    }




 public int getcountt(){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery("Select count(*) from finaldetail",null);
        c.moveToFirst();
        int recount = c.getInt(0);
        c.close();
        return recount;
        }

      public Cursor getalldata(String username){
        SQLiteDatabase db = this.getReadableDatabase();
     Cursor cursor = db.rawQuery("select * from finaldetail where username=?",new String[]{username});
     return cursor;
      }


      //Admin login in deatil
    public  boolean adminlogin(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
            ContentValues cv = new ContentValues();
            cv.put("username",username);
            cv.put("password",password);
            long e = db.insert("admin", null,cv);
            if(e == -1)
                return true;
               return false;

    }
public  boolean adminenter(String username, String password)
{
    SQLiteDatabase db = this.getReadableDatabase();
    Cursor c = db.rawQuery("Select * from admin where usernam=? and password=?",new String[]{username,password});
    if(c.getCount()>0)
    return  true;
    else
        return false;
}


    public Cursor getalldataadmin(){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select * from finaldetail",null);
        return cursor;
    }

public  boolean compstatus(String id){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues c = new ContentValues();
        c.put("status","resolve");
       long res = db.update( "finaldetail",c ,"id=?",new String[]{id});
       if(res == -1 )
        return false;
       else
           return true;
}
}