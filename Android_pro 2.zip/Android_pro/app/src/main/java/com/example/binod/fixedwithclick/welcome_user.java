package com.example.binod.fixedwithclick;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class welcome_user extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    Calendar calendar;
    SimpleDateFormat simpleDateFormat;
   String Date;

    Spinner spinner1,spinner2;
    TextView department,complaintype,username,youhaveselected,datetimeview;
    EditText others;
    Button location;
    String state[]=null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_welcome_user);


        username = (TextView) findViewById(R.id.welcome_username);

       username.setText(getIntent().getStringExtra("Username"));

        spinner1 = (Spinner) findViewById(R.id.spinner1);
        spinner2 = (Spinner) findViewById(R.id.spinner2);
        department = (TextView) findViewById(R.id.department);
        complaintype = (TextView) findViewById(R.id.complaintype);
        others = (EditText) findViewById(R.id.others);
        location = (Button) findViewById(R.id.location);

        youhaveselected =(TextView) findViewById(R.id.youhaveselected);
       // youhaveselected.setVisibility(View.INVISIBLE);


        Button gotomap = (Button) findViewById(R.id.map1);

        datetimeview = (TextView) findViewById(R.id.datetime);
        datetimeview.setVisibility(View.INVISIBLE);

        calendar = Calendar.getInstance();
        simpleDateFormat = new SimpleDateFormat("dd-mm-yyyy    hh:mm:ss");
        Date = simpleDateFormat.format(calendar.getTime());
        datetimeview.setText(Date);

        spinner1.setOnItemSelectedListener(this);


        gotomap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(v.getId() == R.id.map1) {

                    username = (TextView) findViewById(R.id.welcome_username);
                    department = (TextView) findViewById(R.id.department);
                    complaintype = (TextView) findViewById(R.id.complaintype);
                    others = (EditText) findViewById(R.id.others);

                    String u = username.getText().toString();
                    String d = department.getText().toString();
                    String c = complaintype.getText().toString();
                    String o = others.getText().toString();
                    String dt = datetimeview.getText().toString();
                    if (d.equals("") || (c.equals("") && o.equals(""))) {
                        Toast.makeText(welcome_user.this, "Please select department ", Toast.LENGTH_SHORT).show();
                    } else {
                        Intent j = new Intent(welcome_user.this, MapToSelect.class);

                        j.putExtra("USERNAME", u);
                        j.putExtra("DEPARTMENT", d);
                        j.putExtra("COMPLAIN", c);
                        j.putExtra("OTHERS", o);
                        j.putExtra("DATE",dt);
                        startActivity(j);
                    }
                }
                }
        });
    }


    @Override
    public void onItemSelected(final AdapterView<?> parent, View view,final int position, long id) {

            if (position == 0) {
                state = new String[]{"Select"};
            }
            if (position == 1) {
                state = new String[]{"water log", "pot holes", "garbage not clean", "Street light not working", "others"};
            }
            if (position == 2) {
                state = new String[]{"Sewage leak", "water pipe leak", "others"};
            }
            if (position == 3) {
                state = new String[]{"short circuit", "electric pole fallen", "others"};
            }
            if (position == 4) {
                state = new String[]{"Traffic Signal not working  ", "Illegal parking", "others"};

            }

            ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, state);
            spinner2.setAdapter(arrayAdapter);

        location.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(v.getId() == R.id.location) {

                    if (parent.getItemAtPosition(position).equals("Select")) {
                        department.setText("");
                        complaintype.setText("");
                        Toast.makeText(welcome_user.this, "please select Department and complain ", Toast.LENGTH_SHORT).show();

                    } else {

                        String item1 = spinner1.getSelectedItem().toString();
                        String item2 = spinner2.getSelectedItem().toString();

                        department.setText(item1);
                        complaintype.setText(item2);

                        String s = complaintype.getText().toString();
                    if(s.equals("others")) {
                        complaintype.setVisibility(View.INVISIBLE);
                        complaintype.setText(null);
                        others.setVisibility(View.VISIBLE);
                    }
                    else
                    {
                        complaintype.setVisibility(View.VISIBLE);
                        others.setText(null);
                        others.setVisibility(View.INVISIBLE);
                    }
                        youhaveselected.setVisibility(View.VISIBLE);

                        datetimeview.setVisibility(View.VISIBLE);
                    }

                }
            }
        });


        }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

   public void mapview(View v){

                }
                public void registercomplain(View v){
        if(v.getId() == R.id.viewcomplain){
            username = (TextView) findViewById(R.id.welcome_username);
            String username1 = username.getText().toString();
            Intent intent = new Intent(welcome_user.this, Bookdetail.class);
            intent.putExtra("USERNAME", username1);
            startActivity(intent);
        }
                }

                public void logout(View v){
        Intent i = new Intent(this,User_Login.class);
        i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(i);
       finish();

                }
            }



