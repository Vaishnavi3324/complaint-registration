package com.example.binod.fixedwithclick;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.sql.SQLOutput;
import java.util.Calendar;

public class CaptureImg extends AppCompatActivity implements View.OnClickListener {
    DatabaseHelper db;

    final int REQUEST_CODE_GALLERY = 999;
    Button proceed, upload;
    ImageView imageview;
    TextView f_location, f_username, f_department, f_complain, f_others, f_datetime, f_detaildescription;
    EditText imagename;
    final String status = "pending";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_capture_img);
        db = new DatabaseHelper(this);

        final String status = "pending";

        f_location = (TextView) findViewById(R.id.finallocation);
        f_username = (TextView) findViewById(R.id.finalusername);
        f_department = (TextView) findViewById(R.id.finaldepartment);
        f_complain = (TextView) findViewById(R.id.finalcomplain);
        f_others = (TextView) findViewById(R.id.finalothers);
        f_datetime = (TextView) findViewById(R.id.finaldatetime);
        f_detaildescription = (TextView) findViewById(R.id.detaildescription);

        f_location.setText(getIntent().getStringExtra("LOCATION"));
        f_username.setText(getIntent().getStringExtra("USERNAME"));
        f_department.setText(getIntent().getStringExtra("DEPARTMENT"));
        f_complain.setText(getIntent().getStringExtra("COMPLAIN"));
        f_others.setText(getIntent().getStringExtra("OTHERS"));
        f_datetime.setText(getIntent().getStringExtra("DATE"));

        if (f_others == null) {
            f_complain.setVisibility(View.VISIBLE);
            f_others.setVisibility(View.INVISIBLE);
        }
        if (f_complain.equals("")) {
            f_others.setVisibility(View.VISIBLE);
            f_complain.setVisibility(View.INVISIBLE);
        }

        imagename = (EditText) findViewById(R.id.imagename);
        proceed = (Button) findViewById(R.id.finalconfirm);
        upload = (Button) findViewById(R.id.captureImg);
        imageview = (ImageView) findViewById(R.id.mainImg);


        upload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                ActivityCompat.requestPermissions(CaptureImg.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQUEST_CODE_GALLERY);
                /*Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
               startActivityForResult(i, 1);*/

            }
        });


        proceed.setOnClickListener(CaptureImg.this);


    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permission, @NonNull int[] grantResults) {
        if (requestCode == REQUEST_CODE_GALLERY) {
            if ((grantResults.length > 0 && (grantResults[0] == PackageManager.PERMISSION_GRANTED))) {
                Intent first = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(first,1);
                first.setType("image/*");


            } else {
                Toast.makeText(getApplicationContext(), "You dont have the permission to access the file", Toast.LENGTH_SHORT).show();
            }
            return;
        }
        super.onRequestPermissionsResult(requestCode, permission, grantResults);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        Bitmap bitmap = (Bitmap) data.getExtras().get("data");
        imageview.setImageBitmap(bitmap);

    }


    public void AddData(String username, String department, String complain, String others, String location, byte[] imgImage, String imgname, String datetime, String detaildescrip, String status1) {
        //  db = new DatabaseHelper(this);
        boolean insert = db.finalinsert(username, department, complain, others, location, imgImage, imgname, datetime, detaildescrip, status1);
        if (insert == true) {
            Toast.makeText(CaptureImg.this, "Submitted complain successfully", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(CaptureImg.this, "Somthing went wrong", Toast.LENGTH_SHORT).show();
        }

    }



        private byte[] imageViewTobyte(ImageView image) {
            Bitmap bitmap = ((BitmapDrawable)image.getDrawable()).getBitmap();
            ByteArrayOutputStream stream = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
            byte[] byteArray = stream.toByteArray();
            return byteArray;
        }

    @Override
    public void onClick(View v) {
        if(v.getId() == R.id.finalconfirm) {
            String imgname = imagename.getText().toString();
            byte[] imgImage = imageViewTobyte(imageview);
            String username = f_username.getText().toString();
            String department = f_department.getText().toString();
            String complain = f_complain.getText().toString();
            String others = f_others.getText().toString();
            String location = f_location.getText().toString();
            String datetime = f_datetime.getText().toString();
            String detaildescrip = f_detaildescription.getText().toString();
            String status1 = status;


           if(imgImage.length == 0)
                    {
                        Toast.makeText(getApplicationContext(),"no image",Toast.LENGTH_SHORT).show();
                    }


            if (detaildescrip.isEmpty()) {
                Toast.makeText(getApplicationContext(), "enter the description", Toast.LENGTH_SHORT).show();
            }
           else if (imageview.equals(false)) {
                Toast.makeText(CaptureImg.this, "Take image", Toast.LENGTH_SHORT).show();

            }
           else if (imgname.isEmpty() || detaildescrip.isEmpty()) {
                Toast.makeText(CaptureImg.this, "Please enter file name", Toast.LENGTH_SHORT).show();
            } else {
                //(imgname.length() != 0 && (!(imgImage.equals("")))) {
                AddData(username, department, complain, others, location, imgImage, imgname, datetime, detaildescrip, status1);
                Intent intent = new Intent(CaptureImg.this, Bookdetail.class);
                intent.putExtra("USERNAME", username);
                intent.putExtra("DEPARTMENT", department);
                intent.putExtra("COMPLAIN", complain);
                intent.putExtra("OTHERS", others);
                intent.putExtra("LOCATION", location);
                intent.putExtra("DATETIME", datetime);
                intent.putExtra("DETAILDESCRIP", detaildescrip);
                intent.putExtra("STATUS", status1);
                startActivity(intent);
            }
        }

    }
    }


