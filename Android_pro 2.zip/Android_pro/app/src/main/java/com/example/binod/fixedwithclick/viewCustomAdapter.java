package com.example.binod.fixedwithclick;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class viewCustomAdapter extends BaseAdapter {


    private Context context;
    private int layout;
    private ArrayList<Model> viewList;
    private ArrayList<adimCustomAdapter> viewlist1;

    public viewCustomAdapter(Context context, int layout, ArrayList<Model> viewList){
        this.context = context;
        this.layout = layout;
        this.viewList = viewList;
    }

    @Override
    public int getCount() {
        return viewList.size();
    }

    @Override
    public Object getItem(int i) {
        return viewList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    private class ViewHolder{
        ImageView listimageView;
        TextView txtusername, txtdepartment, txtcomplain,txtothers, txtlocation,txtdatetime,txtdetaildescrip;
        TextView txtstatus;

    }

    @Override
    public View getView(int i, View convertView, ViewGroup parent) {

        View row = convertView;
        ViewHolder holder = new ViewHolder();

        if(row == null){
            LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            row = inflater.inflate(layout, null);
            holder.txtusername = row.findViewById(R.id.txtusename);
            holder.txtdepartment = row.findViewById(R.id.txtdepartment);
            holder.txtcomplain = row.findViewById(R.id.txtcomplain);
            holder.txtothers = row.findViewById(R.id.txtothers);
            holder.txtlocation = row.findViewById(R.id.txtlocation);
            holder.listimageView = row.findViewById(R.id.listimageView);
            holder.txtstatus = row.findViewById(R.id.txtstatus);
            holder.txtdatetime = row.findViewById(R.id.txtdatetime);
            holder.txtdetaildescrip = row.findViewById(R.id.txtdetaildescrip);

            row.setTag(holder);
        }
        else{
            holder = (ViewHolder) row.getTag();
        }

        Model model =  viewList.get(i);

        holder.txtusername.setText(model.getUsername());
        holder.txtdepartment.setText(model.getDepartment());
        holder.txtcomplain.setText(model.getComplain());

       if(model.getComplain().equals("")){
           holder.txtcomplain.setVisibility(View.GONE);
           holder.txtothers.setVisibility(View.VISIBLE);
       }else{
           holder.txtcomplain.setVisibility(View.VISIBLE);
           holder.txtothers.setVisibility(View.GONE);
       }
        holder.txtothers.setText(model.getOthers());
        holder.txtlocation.setText(model.getLocation());

        holder.txtstatus.setText(model.getStatus());
        if(model.getStatus().equals("resolve")){
            holder.txtstatus.setTextColor(Color.BLUE);
        }else{
            holder.txtstatus.setTextColor(Color.RED);
        }

        byte[] recordImage = model.getImage();
        Bitmap bitmap = BitmapFactory.decodeByteArray(recordImage, 0, recordImage.length);
        holder.listimageView.setImageBitmap(bitmap);

        holder.txtdatetime.setText(model.getDateTime());
        holder.txtdetaildescrip.setText(model.getDetaildescrip());


        return row;

    }
}
