package com.example.binod.fixedwithclick;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class Admin_controller extends AppCompatActivity {
DatabaseHelper db;
TextView count;
Button admin_logout;

    ListView nlistview;
    ArrayList<Model> nList;
    adimCustomAdapter nAdapter = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_admin_controller);

        admin_logout = (Button) findViewById(R.id.adminlogout);

        admin_logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(v.getId() == R.id.adminlogout)
                {
                    Intent i = new Intent(Admin_controller.this, Admin_login.class);
                    i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(i);
                    finish();


                }
            }
        });

        db = new DatabaseHelper(this);
        count = (TextView) findViewById(R.id.count);

        int count1 = db.getcountt();
        count.setText(String.valueOf(count1));


      //  db = new DatabaseHelper(this);
        nlistview = (ListView) findViewById(R.id.nlistview);
        nList = new ArrayList<>();
        nAdapter = new adimCustomAdapter(this, R.layout.admin_list_item, nList);
        nlistview.setAdapter(nAdapter);

        Cursor cursor = db.getalldataadmin();
        while (cursor.moveToNext()) {
            int did = cursor.getInt(0);
            String dusername = cursor.getString(1);
            String ddepartment = cursor.getString(2);
            String dcomplain = cursor.getString(3);
            String dothers = cursor.getString(4);
            String dlocation = cursor.getString(5);
            byte[] dimage = cursor.getBlob(6);
            String dDateTime = cursor.getString(8);
            String ddetaildesctip = cursor.getString(9);
            String dstatus = cursor.getString(10);

            nList.add(new Model(did,dusername, ddepartment, dcomplain, dothers, dlocation, dimage,dDateTime, ddetaildesctip, dstatus));
        }
        nAdapter.notifyDataSetChanged();
        if (nList.size() == 0) {
            Toast.makeText(this, "no record found", Toast.LENGTH_LONG).show();
        }
        nlistview.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(Admin_controller.this,"selected ",Toast.LENGTH_SHORT).show();
                return false;
            }

        });

    }

}

