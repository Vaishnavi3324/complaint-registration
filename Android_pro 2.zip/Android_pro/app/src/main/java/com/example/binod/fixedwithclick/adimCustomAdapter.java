package com.example.binod.fixedwithclick;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.IntentCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.support.v4.content.IntentCompat;
import java.util.ArrayList;

import static android.graphics.Color.GREEN;
import static android.support.v4.content.ContextCompat.startActivity;

public class adimCustomAdapter  extends BaseAdapter {

SQLiteDatabase db1;
DatabaseHelper inthis;
    DatabaseHelper db;
    private String status = "resolve";
private Context context;
private int layout;
private ArrayList<Model> viewList;

public adimCustomAdapter(Context context,int layout, ArrayList<Model> viewList){
    this.context = context;
    this.layout = layout;
    this.viewList = viewList;
}


    @Override
    public int getCount() {
        return viewList.size();
    }

    @Override
    public Object getItem(int position) {
        return viewList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }


    public  class ViewHolder
    {
        ImageView adminimage;
        TextView adminusername,admindeparment,admincomplain,adminlocation,adminid,adminothers, admindatetime, admindetaildescrip;
        Button adminresolve;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

    View row = convertView;
    ViewHolder holder = new ViewHolder();

        if (row == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            row = inflater.inflate(layout, null);

            holder.adminid = row.findViewById(R.id.adminid);
            holder.adminusername = row.findViewById(R.id.adminusername);
            holder.admindeparment = row.findViewById(R.id.admindepartment);
            holder.admincomplain = row.findViewById(R.id.admincomplain);
            holder.adminothers = row.findViewById(R.id.adminothers);
            holder.adminlocation = row.findViewById(R.id.adminlocation);
            holder.adminresolve = row.findViewById(R.id.adminreslove);
            holder.adminimage = row.findViewById(R.id.adminimage);
            holder.admindatetime = row.findViewById(R.id.admindatetime);
            holder.admindetaildescrip = row.findViewById(R.id.admindetaildescrip);


            final ViewHolder finalHolder = holder;
            final ViewHolder finalHolder1 = holder;
            holder.adminresolve.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(v.getId() == R.id.adminreslove) {
                        inthis = new DatabaseHelper(context.getApplicationContext());
                        db = new DatabaseHelper(context.getApplicationContext());
                        String resolve = finalHolder.adminresolve.getText().toString();
                        String id  = finalHolder.adminid.getText().toString();

                        if (resolve.equals("resolve") || resolve.equals("RESOLVE")) {
                            Toast.makeText(context.getApplicationContext(), "Complain is resolved and closed", Toast.LENGTH_LONG).show();
                        } else {
                            boolean compstatus = db.compstatus(id);
                            if(compstatus == true)
                            {
                                Intent i = new Intent(context.getApplicationContext(),Admin_controller.class);
                               context.startActivity(i);
                               Toast.makeText(context.getApplicationContext(), "Successfully Resolved", Toast.LENGTH_LONG).show();

                            }else {
                                Toast.makeText(context.getApplicationContext(), "not working", Toast.LENGTH_LONG).show();
                            }
                        }
                    }
                }
            });

            row.setTag(holder);
        } else {
            holder = (adimCustomAdapter.ViewHolder) row.getTag();
        }

        Model model =  viewList.get(position);

        holder.adminid.setText(Integer.toString(model.getId())); //(model.getId());
        holder.adminusername.setText(model.getUsername());
        holder.admindeparment.setText(model.getDepartment());

        if(model.getComplain().equals(""))
        {
            holder.admincomplain.setVisibility(View.INVISIBLE);
            holder.adminothers.setVisibility(View.VISIBLE);
        }else
        {
            holder.admincomplain.setVisibility(View.VISIBLE);
            holder.adminothers.setVisibility(View.INVISIBLE);
        }

        holder.admincomplain.setText(model.getComplain());
        holder.adminothers.setText(model.getOthers());
        holder.adminlocation.setText(model.getLocation());

        if(model.getStatus().equals("resolve")){
            holder.adminresolve.setBackgroundColor(Color.GREEN);
        }else{
            holder.adminresolve.setBackgroundColor(Color.RED);
        }
        holder.adminresolve.setText(model.getStatus());
        holder.admindatetime.setText(model.getDateTime());
        holder.admindetaildescrip.setText(model.getDetaildescrip());

        byte[] recordImage = model.getImage();
        Bitmap bitmap = BitmapFactory.decodeByteArray(recordImage, 0, recordImage.length);
        holder.adminimage.setImageBitmap(bitmap);
        return row;

    }


}
