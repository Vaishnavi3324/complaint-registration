package com.example.binod.fixedwithclick;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class Bookdetail extends AppCompatActivity {
DatabaseHelper db;
RelativeLayout linearLayout;
TextView username;
Button home,userlogout;


ListView mlistview;
ArrayList<Model> mList;
viewCustomAdapter mAdapter = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getSupportActionBar().hide();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bookdetail);
        db = new DatabaseHelper(this);

        linearLayout = findViewById(R.id.mylinear);

        home = (Button) findViewById(R.id.home1);
        userlogout = (Button) findViewById(R.id.userlogout);

            userlogout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent i = new Intent(Bookdetail.this,User_Login.class);
                    i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(i);
                    finish();
                }
            });
        username = (TextView) findViewById(R.id.username);
        username.setText(getIntent().getStringExtra("USERNAME"));

        String username1 = username.getText().toString();


        db = new DatabaseHelper(this);
        mlistview = (ListView) findViewById(R.id.mlistview);
        mList = new ArrayList<>();
        mAdapter = new viewCustomAdapter(this, R.layout.list_item, mList);
        mlistview.setAdapter(mAdapter);

        Cursor cursor = db.getalldata(username1);
            while (cursor.moveToNext()) {
                Integer did = cursor.getInt(0);
                String dusername = cursor.getString(1);
                String ddepartment = cursor.getString(2);
                String dcomplain = cursor.getString(3);
                String dothers = cursor.getString(4);
                String dlocation = cursor.getString(5);
                byte[] dimage = cursor.getBlob(6);
                String dDateTime = cursor.getString(8);
                String ddetaildescrip = cursor.getString(9);
                String dstatus = cursor.getString(10);

        if(dusername.equals(username1)) {
            mList.add(new Model(did,dusername, ddepartment, dcomplain, dothers, dlocation, dimage,dDateTime, ddetaildescrip, dstatus));
        }
            }
            mAdapter.notifyDataSetChanged();
            if (mList.size() == 0) {
                Toast.makeText(this, "no record found", Toast.LENGTH_LONG).show();
            }
            mlistview.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
                @Override
                public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {

                    return false;
                }

            });

    }

    public  void  home(View v)
    {
        if(v.getId() ==  R.id.home1)
        {
             String usenametowelcom = username.getText().toString();
                     Intent i = new Intent(Bookdetail.this, welcome_user.class);
                     i.putExtra("Username", usenametowelcom);
                     startActivity(i);

        }
    }
    }


