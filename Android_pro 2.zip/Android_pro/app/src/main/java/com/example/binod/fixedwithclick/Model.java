package com.example.binod.fixedwithclick;

public class Model {

    private Integer id;
    private String username;
    private  String department;
    private  String complain;
    public  String others;
    private  String location;
    private  String DateTime;
    private  String detaildescrip;
    private  String status;
    private  byte[] image;

  public Model(int id,String username,String department, String complain, String others, String location, byte[] image,String Datetime, String detaildescrip, String status){
      this.id = id;
      this.username = username;
      this.department = department;
      this.complain = complain;
      this.others = others;
      this.location = location;
      this.image = image;
      this.DateTime = Datetime;
      this.detaildescrip = detaildescrip;
      this.status = status;

  }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getComplain() {
        return complain;
    }

    public void setComplain(String complain) {
        this.complain = complain;
    }

    public String getOthers() {
        return others;
    }

    public void setOthers(String others) {
        this.others = others;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public byte[] getImage() {
        return image;
    }

    public void setImage(byte[] image) {
        this.image = image;
    }

    public void setDateTime(String dateTime) {
        DateTime = dateTime;
    }

    public String getDateTime() {
        return DateTime;
    }

    public void setDetaildescrip(String detaildescrip) {
        this.detaildescrip = detaildescrip;
    }

    public String getDetaildescrip() {
        return detaildescrip;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

}
