package com.example.binod.fixedwithclick;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class User_Login extends AppCompatActivity {

    DatabaseHelper db;
    EditText lusername,lpassword;
    Button login;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_user__login);

        db = new DatabaseHelper(this);

        lusername = (EditText)findViewById(R.id.l_username);
        lpassword = (EditText)findViewById(R.id.user_Pass);
        login = (Button)findViewById(R.id.user_login);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String susername = lusername.getText().toString();
                String spassword = lpassword.getText().toString();

                    if(susername.equals("")){
                        Toast.makeText(getApplicationContext(),"Enter uername",Toast.LENGTH_LONG).show();
                    }
                    if(spassword.equals("")){
                        Toast.makeText(getApplicationContext(),"enter password",Toast.LENGTH_LONG).show();
                    }
                    else {

                        boolean checklogin = db.checklogin(susername, spassword);
                        if (checklogin == true) {
                            Toast.makeText(getApplicationContext(), "Login Successfull", Toast.LENGTH_LONG).show();
                            EditText a = (EditText)findViewById(R.id.l_username) ;
                            String str = a.getText().toString();
                            Intent i = new Intent(User_Login.this, welcome_user.class);
                            i.putExtra("Username",str);
                            startActivity(i);
                        } else {
                            Toast.makeText(getApplicationContext(), "Wrong username or passwor", Toast.LENGTH_LONG).show();
                        }
                    }

            }
        });

    }

public void welcome_signup(View v)
  {
    if (v.getId() == R.id.user_register)
    {
        Intent i = new Intent(User_Login.this, user_register.class);
        startActivity(i);
    }
        if (v.getId() == R.id.user_login)
        {
            EditText a = (EditText)findViewById(R.id.l_username) ;
            String str = a.getText().toString();

            Intent i = new Intent(User_Login.this, welcome_user.class);
            i.putExtra("Username",str);
            startActivity(i);
        }

    }

    public  void  adminlogin(View v)
    {
        startActivity(new Intent(User_Login.this, Admin_login.class ));
    }

}