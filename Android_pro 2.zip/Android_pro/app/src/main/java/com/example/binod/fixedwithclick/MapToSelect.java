package com.example.binod.fixedwithclick;

import android.Manifest;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
//import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.gms.common.api.GoogleApi;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.internal.ICameraUpdateFactoryDelegate;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.location.LocationListener;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

public class MapToSelect extends AppCompatActivity implements OnMapReadyCallback, GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener, LocationListener {

    static final int MY_PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION = 1;
    GoogleMap mGoogleMap;
    GoogleApiClient mGoogleApiClient;
    LocationManager mLocationManager;
    TextView locationText;
    TextView department_f,complain_f,username_f,others_ff,datetime_f;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        if (googleServicesAvailable()) {
            Toast.makeText(this, "google service is avilable", Toast.LENGTH_SHORT).show();
            setContentView(R.layout.activity_map_to_select);
            initMap();

            locationText = (TextView) findViewById(R.id.locationText);

            username_f = (TextView) findViewById(R.id.username_f);
            department_f = (TextView) findViewById(R.id.department_f);
            complain_f = (TextView) findViewById(R.id.complain_f);
            others_ff = (TextView) findViewById(R.id.others_f);
            datetime_f =(TextView) findViewById(R.id.datetime_f);

            username_f.setText(getIntent().getStringExtra("USERNAME"));
            department_f.setText(getIntent().getStringExtra("DEPARTMENT"));
            complain_f.setText(getIntent().getStringExtra("COMPLAIN"));
            others_ff.setText(getIntent().getStringExtra("OTHERS"));
            datetime_f.setText(getIntent().getStringExtra("DATE"));



        } else {
            //is google maps is not supported
            Toast.makeText(this, "Make sure Mobile data or location is enable ", Toast.LENGTH_SHORT).show();
        }

    }




    private void initMap() {
        MapFragment mapFragment = (MapFragment) getFragmentManager().findFragmentById(R.id.mapFragment);
        mapFragment.getMapAsync((OnMapReadyCallback) this);
    }

    public boolean googleServicesAvailable() {
        GoogleApiAvailability api = GoogleApiAvailability.getInstance();
        int isAvaibale = api.isGooglePlayServicesAvailable(this);
        if (isAvaibale == ConnectionResult.SUCCESS) {
            return true;
        } else if (api.isUserResolvableError(isAvaibale)) {
            Dialog dialog = api.getErrorDialog(this, isAvaibale, 0);
            dialog.show();
        } else {
            Toast.makeText(this, "Cant connect to play store", Toast.LENGTH_SHORT).show();
        }
        return false;
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mGoogleMap = googleMap;
        // goToLocationZoom(39.008224, -76.8984527, 15);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                    && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED)
            {
                // TODO: Consider calling
                //    ActivityCompat#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for ActivityCompat#requestPermissions for more details.
                ActivityCompat.requestPermissions(MapToSelect.this,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                        MY_PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION);

               return;

                //Toast.makeText(this,"turn on the gps",Toast.LENGTH_SHORT).show();

            }

        else {
                mGoogleMap.setMyLocationEnabled(true);
                mGoogleApiClient = new GoogleApiClient.Builder(this).addApi(LocationServices.API).addConnectionCallbacks(this).addOnConnectionFailedListener(this).build();
                mGoogleApiClient.connect();
            }
        }
    }


    @Override
    public void onRequestPermissionsResult(
            int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {

        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(MapToSelect.this,
                            "permission was granted, :)",
                            Toast.LENGTH_LONG).show();

                    mGoogleMap.setMyLocationEnabled(true);
                    mGoogleApiClient = new GoogleApiClient.Builder(this).addApi(LocationServices.API).addConnectionCallbacks(this).addOnConnectionFailedListener(this).build();
                    mGoogleApiClient.connect();


                } else {
                    Toast.makeText(MapToSelect.this,
                            "permission denied, ...:(",
                            Toast.LENGTH_LONG).show();
                }
                return;
            }

        }
    }


    private void goToLocation(double lat, double lng) {
        LatLng ll = new LatLng(lat, lng);
        CameraUpdate update = CameraUpdateFactory.newLatLng(ll);
        mGoogleMap.moveCamera(update);

    }

    private void goToLocationZoom(double lat, double lng, float Zoom) {
        LatLng ll = new LatLng(lat, lng);
        CameraUpdate update = CameraUpdateFactory.newLatLngZoom(ll, Zoom);
        mGoogleMap.moveCamera(update);
    }

    public void geoLocate(View view) throws IOException {

        if(view.getId() == R.id.mapbutton){

            username_f = (TextView) findViewById(R.id.username_f);
            department_f = (TextView) findViewById(R.id.department_f);
            complain_f = (TextView) findViewById(R.id.complain_f);
            locationText = (TextView) findViewById(R.id.locationText);
            others_ff = (TextView) findViewById(R.id.others_f);


            String u = username_f.getText().toString();
            String d = department_f.getText().toString();
            String c = complain_f.getText().toString();

            String l = locationText.getText().toString();

            String o = others_ff.getText().toString();
            String dt = datetime_f.getText().toString();

            if(l.equals(""))
            {
                Toast.makeText(MapToSelect.this,"please allow the gps to auto select location", Toast.LENGTH_LONG).show();
            } else {

                Intent imagepage = new Intent(MapToSelect.this, CaptureImg.class);
                imagepage.putExtra("USERNAME", u);
                imagepage.putExtra("DEPARTMENT", d);
                imagepage.putExtra("COMPLAIN", c);
                imagepage.putExtra("LOCATION", l);
                imagepage.putExtra("OTHERS", o);
                imagepage.putExtra("DATE", dt);
                startActivity(imagepage);
            }
        }

    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.hellomaps, menu);
        return super.onCreateOptionsMenu(menu);
    }

    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case R.id.mapTypeNone:
                mGoogleMap.setMapType(GoogleMap.MAP_TYPE_NONE);
                break;

            case R.id.mapTypeNormal:
                mGoogleMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
                break;

            case R.id.mapTypeSatellite:
                mGoogleMap.setMapType(GoogleMap.MAP_TYPE_SATELLITE);
                break;

            case R.id.mapTypeTerrain:
                mGoogleMap.setMapType(GoogleMap.MAP_TYPE_TERRAIN);
                break;


            case R.id.mapTypeHybrid:
                mGoogleMap.setMapType(GoogleMap.MAP_TYPE_HYBRID);
                break;

            default:
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    LocationRequest mLocationRequest;

    @Override
    public void onConnected(@Nullable Bundle bundle) {
        mLocationRequest = LocationRequest.create();
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        mLocationRequest.setInterval(1);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                // TODO: Consider calling)
                return;
            }
        }
        LocationServices.FusedLocationApi.requestLocationUpdates(mGoogleApiClient, mLocationRequest, this);


    }

    @Override
    public void onConnectionSuspended(int i) {

    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }

    @Override
    public void onLocationChanged(Location location) {

        if (location == null) {
            Toast.makeText(this, "cant get  location", Toast.LENGTH_SHORT).show();

        } else {

            locationText.setText("Latitude: " + location.getLatitude() + "\n Longitude: " + location.getLongitude());

            try {
                Geocoder geocoder = new Geocoder(this, Locale.getDefault());
                List<Address> addresses = geocoder.getFromLocation(location.getLatitude(), location.getLongitude(), 1);
                locationText.setText(addresses.get(0).getAddressLine(0) + ", " + addresses.get(0).getAddressLine(1) + ", " + addresses.get(0).getAddressLine(2));
            } catch (Exception e) {

            }

            LatLng ll = new LatLng(location.getLatitude(), location.getLongitude());
            CameraUpdate update = CameraUpdateFactory.newLatLngZoom(ll, 19);
            mGoogleMap.animateCamera(update);
        }
    }

    public void onProviderDisabled(String provider) {
        Toast.makeText(this, "Please Enable GPS and Internet", Toast.LENGTH_SHORT).show();
    }
}


