package com.example.binod.fixedwithclick;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Admin_login extends AppCompatActivity {

    DatabaseHelper db;
    Button adminloginbtn,fromadmintouser;
    EditText adminusername, adminpassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_login);
getSupportActionBar().hide();
        db = new DatabaseHelper(Admin_login.this);
        adminusername = (EditText) findViewById(R.id.adusername);
        adminpassword = (EditText)  findViewById(R.id.adpassword);
        adminloginbtn =  (Button)  findViewById(R.id.adminloginbtn);
        fromadmintouser =(Button) findViewById(R.id.fromadmintouser) ;

        fromadmintouser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Admin_login.this,User_Login.class));
            }
        });

        adminloginbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String adminname = adminusername.getText().toString().trim();
                String adminpass = adminpassword.getText().toString();

                if(adminname.equals("ben") && adminpass.equals("123")){

                    Intent i = new Intent(Admin_login.this, Admin_controller.class);
                        startActivity(i);
                        Toast.makeText(Admin_login.this,"welcome "+ adminname+ ":)",Toast.LENGTH_SHORT).show();
                    }else{
                    Toast.makeText(Admin_login.this,"Enter username and password",Toast.LENGTH_SHORT).show();
                    adminusername.setText(null);
                    adminpassword.setText(null);
                }

                    }

        });

    }
}
